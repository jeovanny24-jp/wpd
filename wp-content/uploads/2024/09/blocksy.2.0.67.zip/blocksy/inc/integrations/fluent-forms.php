<?php

add_filter('fluentform/load_theme_style', function ($preference) {
    return true;
});